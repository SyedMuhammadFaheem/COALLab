# About the project
This work present project number 13 for the school year 2016/2017 in [the computer electronics](http://tnt.etf.rs/~oe3re/) in the 3rd year, Department of Electronics, School of Electrical Engineering, University of Belgrade. The basic idea for this work was the development game "Hangman" using Microsoft Visual Studio 2015 as a software tool and Irvine librari.

# Installation
To start the game you need the following programs:
1. vs_community_ENU.exe
2. Irvine_7th_Edition.msi
3. AsmHighlighter.vsix

# Modification and defense project
Modification of the project which was requested from me on the oral defense, was simpy restarting the game when you press 
SPACE on the keyboard. It also represents the version v1.0 of the game.

# Acknowledgment
I dedicate this game to [rkhb](https://stackoverflow.com/users/3512216/rkhb), who had plenty of patience to answer all my questions regarding assembler, Irvine and MASM. Thank you from the heart.

# Screenshot of game

![1](https://user-images.githubusercontent.com/16638876/26972268-5643281a-4d11-11e7-851e-1fd6253bbb9e.png)

![2](https://user-images.githubusercontent.com/16638876/26972276-5c4341dc-4d11-11e7-868b-4529c6f319fd.png)

![3](https://user-images.githubusercontent.com/16638876/26972284-61cfe3c6-4d11-11e7-8828-bd991efeb40c.png)
